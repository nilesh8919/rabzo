<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MerchantPaymentProvider extends ApiModel
{
    public $table = 'mt_merchant_payment_provider';
    public $timestamps = false;

   

}
