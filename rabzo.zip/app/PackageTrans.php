<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PackageTrans extends ApiModel
{
    public $table = 'mt_package_trans';
    public $timestamps = false;

   

}
