<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CookingReference extends ApiModel
{
    public $table = 'mt_cooking_ref';
    public $timestamps = false;

   

}
