<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Client extends ApiModel
{
    public $table = 'mt_client';
    public $timestamps = false;

   

}
