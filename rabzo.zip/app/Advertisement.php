<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Advertisement extends ApiModel
{
    public $table = 'mt_advertisement';
    public $timestamps = false;

   

}
