<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderDeliveryAddress extends ApiModel
{
    public $table = 'mt_order_delivery_address';
    public $timestamps = false;

   

}
