<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MerchantOpenClose extends ApiModel
{
    public $table = 'mt_merchant_open_close';
    public $timestamps = false;

   

}
