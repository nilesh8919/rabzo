<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Banner extends ApiModel
{
    public $table = 'banners';
    public $timestamps = true;

   

}
