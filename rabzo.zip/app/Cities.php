<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cities extends ApiModel
{
    public $table = 'mt_location_cities';
    public $timestamps = false;

   

}
