<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Offer extends ApiModel
{
    public $table = 'mt_offers';
    public $timestamps = false;

   

}
