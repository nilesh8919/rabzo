<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Option extends ApiModel
{
    public $table = 'mt_option';
    public $timestamps = false;

   

}
