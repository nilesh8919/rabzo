<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Faq extends ApiModel
{
    public $table = 'faqs';
    public $timestamps = true;

   

}
