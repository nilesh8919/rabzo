<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ItemImages extends ApiModel
{
    public $table = 'mt_item_images';
    public $timestamps = false;

   

}
