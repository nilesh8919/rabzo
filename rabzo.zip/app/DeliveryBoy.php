<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DeliveryBoy extends ApiModel
{
    public $table = 'mt_delivery_boy';
    public $timestamps = false;

   

}
