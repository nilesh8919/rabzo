<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Categories extends ApiModel
{
    public $table = 'mt_category';
    public $timestamps = false;

   

}
