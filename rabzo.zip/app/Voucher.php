<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Voucher extends ApiModel
{
    public $table = 'mt_voucher_new';
    public $timestamps = false;

   

}
