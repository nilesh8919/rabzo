<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MerchantCuisine extends ApiModel
{
    public $table = 'mt_merchant_cuisine';
    public $timestamps = false;

   

}
