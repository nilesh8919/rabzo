<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ingredients extends ApiModel
{
    public $table = 'mt_ingredients';
    public $timestamps = false;

   

}
