<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShippingRate extends ApiModel
{
    public $table = 'mt_shipping_rate';
    public $timestamps = false;

   

}
