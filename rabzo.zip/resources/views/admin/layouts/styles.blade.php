  <link href="admintemplate/css/bootstrap.min.css" rel="stylesheet">
    <link href="admintemplate/font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="admintemplate/css/animate.css" rel="stylesheet">
    <link href="admintemplate/css/style.css" rel="stylesheet">
	   <link href="admintemplate/css/plugins/dataTables/datatables.min.css" rel="stylesheet">
 <link href="admintemplate/css/plugins/summernote/summernote.css" rel="stylesheet">
    <link href="admintemplate/css/plugins/summernote/summernote-bs3.css" rel="stylesheet">
	<script src="admintemplate/js/jquery-3.1.1.min.js"></script>
    <script src="admintemplate/js/bootstrap.min.js"></script>
    <script src="admintemplate/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="admintemplate/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
<script src="admintemplate/js/plugins/dataTables/datatables.min.js"></script>
    <!-- Flot -->
    <script src="admintemplate/js/plugins/flot/jquery.flot.js"></script>
    <script src="admintemplate/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="admintemplate/js/plugins/flot/jquery.flot.spline.js"></script>
    <script src="admintemplate/js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="admintemplate/js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="admintemplate/js/plugins/flot/jquery.flot.symbol.js"></script>
    <script src="admintemplate/js/plugins/flot/jquery.flot.time.js"></script>

    <!-- Peity -->
    <script src="admintemplate/js/plugins/peity/jquery.peity.min.js"></script>
    <script src="admintemplate/js/demo/peity-demo.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="admintemplate/js/inspinia.js"></script>
    <script src="admintemplate/js/plugins/pace/pace.min.js"></script>

    <!-- jQuery UI -->
    <script src="admintemplate/js/plugins/jquery-ui/jquery-ui.min.js"></script>

    <!-- Jvectormap -->
    <script src="admintemplate/js/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="admintemplate/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <!-- EayPIE -->
    <script src="admintemplate/js/plugins/easypiechart/jquery.easypiechart.js"></script>

    <!-- Sparkline -->
    <script src="admintemplate/js/plugins/sparkline/jquery.sparkline.min.js"></script>

    <!-- Sparkline demo data  -->
    <script src="admintemplate/js/demo/sparkline-demo.js"></script>
	 <script src="admintemplate/js/plugins/summernote/summernote.min.js"></script>
	 
	  <!-- Chosen -->
    <script src="admintemplate/js/plugins/chosen/chosen.jquery.js"></script>
    <script src="admintemplate/js/plugins/metisMenu/jquery.metisMenu.js"></script>


    <!--datepicker js-->
  
    <script src="admintemplate/js/plugins/cropper/cropper.min.js"></script>
    <script src="admintemplate/js/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>
	<link href="admintemplate/css/plugins/chosen/bootstrap-chosen.css" rel="stylesheet">
	  <script src="admintemplate/js/plugins/datapicker/bootstrap-datepicker.js"></script>
	<link href="admintemplate/css/plugins/datapicker/datepicker3.css" rel="stylesheet">
	<link href="admintemplate/css/plugins/switchery/switchery.css"  rel="stylesheet">
	 <script src="admintemplate/js/plugins/switchery/switchery.js"></script>

			<link rel="stylesheet" href="admintemplate/plugins/bootstrap-fileupload/bootstrap-fileupload.min.css">
			 <script src="admintemplate/plugins/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>
