<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends ApiModel
{
    public $table = 'mt_order';
    public $timestamps = false;

   

}
