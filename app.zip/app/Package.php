<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Package extends ApiModel
{
    public $table = 'mt_packages';
    public $timestamps = false;

   

}
