<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Review extends ApiModel
{
    public $table = 'mt_review';
    public $timestamps = false;

   

}
