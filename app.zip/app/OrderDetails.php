<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderDetails extends ApiModel
{
    public $table = 'mt_order_details';
    public $timestamps = false;

   

}
