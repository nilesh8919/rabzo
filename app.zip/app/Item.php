<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Item extends ApiModel
{
    public $table = 'mt_item';
    public $timestamps = false;

   

}
