<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MerchantCategories extends ApiModel
{
    public $table = 'mt_merchant_categories';
    public $timestamps = false;

   

}
